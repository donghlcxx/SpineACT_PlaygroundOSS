#pragma once
#include <spine/spine.h>
#include <TextureManagement.h>

namespace oxspine
{ 
    void init();
    void free();

    spine::TextureLoader *getTextureLoader();

	class SpineActor
	{
	public:
		bool AddSpine(CKLBImageAsset* pImgAsset, const char *atlasStr, const char*jsonStr);
		void doRender(CKLBImageAsset* pImgAsset);
		void execute(u32 deltaT);
		void floatCopy(float* des, float* or , float* uv);
		void shortCopy(unsigned short* des, unsigned short* or );
		void changerAnimation(const char *animation, bool isloop);
		SpineActor() {
		}
		~SpineActor() {
			delete skeleton;
			skeleton = 0;
			delete skeletonData;
			skeletonData = 0;
			delete animationState;
			animationState = 0;
			delete animationState;
			animationState = 0;
			delete animationStateData;
			animationStateData = 0;
			delete atlas;
			atlas = 0;
		}
	protected:

		spine::AnimationStateData* animationStateData = 0;
		spine::AnimationState* animationState = 0;
		spine::SkeletonData *skeletonData = 0;
		spine::Atlas* atlas = 0;
		spine::Skeleton *skeleton = 0;
		int vertextIndex = 0;
		int indexIndex = 0;
		spine::RegionAttachment* regionAttachment;
		spine::MeshAttachment* mesh;
		bool isRegion = true;
		spine::Vector<float> uvs;
		CKLBImageAsset* pImgAsset;
		float uOffset = 0;
		float vOffset = 0;
		float uMax = 1;
		float vMax = 1;
	};
}