function setup()
	syslog("a")
    FONT_load("AlexBrush","asset://JianZhunYuan.ttf")
	pLableTitle = UI_Label 	(
							nil, 			-- <parent pointer>, 
							7001, 			-- <order>, 
							400,20,		-- <x>, <y>,
                            0xFF, 0xFFFFFF,	-- <alpha>, <rgb>, 
							"heiti",	-- "<font name>", 
							50,				-- <font size>, 
							"Spine 动画展示"	-- "<text string>"
						)
		pLableInfo1 = UI_Label 	(
							nil, 			-- <parent pointer>, 
							7001, 			-- <order>, 
							50,70,		-- <x>, <y>,
                            0xFF, 0xFFFFFF,	-- <alpha>, <rgb>, 
							"heiti",	-- "<font name>", 
							30,				-- <font size>, 
							"1、点击任意位置改变动画"	-- "<text string>"
						)
		pLableInfo2 = UI_Label 	(
							nil, 			-- <parent pointer>, 
							7001, 			-- <order>, 
							50,100,		-- <x>, <y>,
                            0xFF, 0xFFFFFF,	-- <alpha>, <rgb>, 
							"heiti",	-- "<font name>", 
							30,				-- <font size>, 
							"2、双击进入战斗"	-- "<text string>"
						)
   canvasBg = UI_Canvas(
		nil,
		5000,
		0,
		0,
		10,
		10,
		"drawfunc"
	)
    sysCommand(canvasBg, UI_CANVAS_ADDRESOURCE, "asset://level_39.png.imag")

    --int tank 
	CanvasTank = UI_Canvas(
		nil,
		7000,
		20,
		20,
		2000,
		2000,
		"drawfunc"
	)
	--sysCommand(tskCanvas, UI_CANVAS_ADDRESOURCE, "asset://TileA.png.imag")	-- 0
	--sysCommand(tskCanvas, UI_CANVAS_ADDRESOURCE, "asset://TileB.png.imag")	-- 1
	--sysCommand(tskCanvas, UI_CANVAS_ADDRESOURCE, "asset://TileC.png.imag")	-- 2
	sysCommand(CanvasTank, UI_CANVAS_ADDRESOURCE, "asset://tank.png.imag",
	"asset://spine/tank.atlas",
	"asset://spine/tank-pro.json")
	
	--init spine boy
	CanvasBoy = UI_Canvas(
		nil,
		7000,
		20,
		20,
		2000,
		2000,
		"drawfunc"
	)
    sysCommand(CanvasBoy, UI_CANVAS_ADDRESOURCE, "asset://spineboy.png.imag",
	"asset://spine/spineboy.atlas",
	"asset://spine/spineboy-pro.json")	-- 2


   pCtrl = UI_Control(
							"onClick",
							"onDrag"
						)
    sysCommand(pCtrl, UI_CONTROL_ON_DBLCLICK, "onDblClick")
	count = 0
    ShowState=0  --0 show 
                 --1 showBG
	currentAnimationIndex=0

end


function execute(deltaT)
	count = count + 1
	if count == 1 then
		changerVisiblecanvas(canvasBg,false)
		--hidecanvas(CanvasBoy)
		--changerAlpha(canvasBg,0)
		changerVisiblecanvas(CanvasTank,false)
	end
	if count == 2 then     --初始化动作
		syslog(string.format("TASK scalex"))
		prop = TASK_getProperty(CanvasBoy)
		prop.scaleX = 0.5
		prop.scaleY = 0.5
		TASK_setProperty(CanvasBoy, prop)	

		prop = TASK_getProperty(CanvasBoy)
		prop.x = 250
		prop.y = 300
		TASK_setProperty(CanvasBoy, prop)	
        sysCommand(CanvasBoy, UI_CANVAS_CHANGERANIMATION, 1,"idle",true)   --注，2个spine都存在一个容器中
	end
	
	if ShowState ==1 then --doanimation
		if count==1 then
		   changerVisiblecanvas(canvasBg,true)
		   hideLable(pLableTitle)
		   hideLable(pLableInfo1)
		   hideLable(pLableInfo2)
		   changerVisiblecanvas(CanvasTank,true)
		   changerScale(CanvasTank,0.15)
		   changePos(CanvasTank,700,300)
		 
	    end
		scale = 0.50- count/200
		changerScale(CanvasBoy,scale)
		changePos(CanvasBoy,-3,0.5)
		if scale<=0.15 then
			count=100
			ShowState=2
		end
	end

	if ShowState ==2  then
       sysCommand(CanvasTank, UI_CANVAS_CHANGERANIMATION, 0,"drive",false)
       if count <200 then
         changePos(CanvasTank,1,0)
        else
     	 ShowState =3
         count=100
        end

	end

	
	
	
	--[[
	count = count + 1
	
	if count == 1 then
		drawfunc(tskCanvas)
	end
	if count == 20 then
		syslog(string.format("TASK alpha"))
		prop = TASK_getProperty(tskCanvas)
		prop.alpha = 128
		TASK_setProperty(tskCanvas, prop)	
	end
	if count == 40 then
		syslog(string.format("TASK color"))
		prop = TASK_getProperty(tskCanvas)
		prop.color = 0xFF00FF
		TASK_setProperty(tskCanvas, prop)	
	end
	if count == 60 then
		syslog(string.format("TASK scalex"))
		prop = TASK_getProperty(tskCanvas)
		prop.scaleX = 2.0
		TASK_setProperty(tskCanvas, prop)	
	end
	if count == 80 then
		syslog(string.format("TASK scaley"))
		prop = TASK_getProperty(tskCanvas)
		prop.scaleY = 2.0
		TASK_setProperty(tskCanvas, prop)	
	end
	if count == 100 then
		syslog(string.format("TASK rot"))
		prop = TASK_getProperty(tskCanvas)
		prop.rot = 25.0
		TASK_setProperty(tskCanvas, prop)	
	end
	if count == 120 then
		syslog(string.format("TASK x"))
		prop = TASK_getProperty(tskCanvas)
		prop.x = 200
		TASK_setProperty(tskCanvas, prop)	
	end
	if count == 140 then
		syslog(string.format("TASK y"))
		prop = TASK_getProperty(tskCanvas)
		prop.y = 200
		TASK_setProperty(tskCanvas, prop)	
	end
	if count == 160 then
		syslog(string.format("TASK visible = false"))
		prop = TASK_getProperty(tskCanvas)
		prop.visible = false
		TASK_setProperty(tskCanvas, prop)	
	end
	if count == 180 then
		syslog(string.format("TASK visible = true"))
		prop = TASK_getProperty(tskCanvas)
		prop.visible = true
		TASK_setProperty(tskCanvas, prop)	
	end
	
	if count == 200 then
		syslog(string.format("CMD UI_CANVAS_DRAWIMAGESCALE"))
		drawScaleFunc(tskCanvas)
	end
	if count == 300 then
		syslog(string.format("CMD UI_CANVAS_FILLRECT"))
		sysCommand(tskCanvas, UI_CANVAS_FILLRECT, 300, 0, 100, 100, 0xff, 0xff00ff)
	end
	if count == 380 then
		syslog(string.format("CMD UI_CANVAS_FREEZE"))
		sysCommand(tskCanvas, UI_CANVAS_FREEZE, false)
	end
	if count == 400 then
		syslog(string.format("CMD DYNAMIC"))
		sysCommand(tskCanvas, UI_CANVAS_FREEZE, true)
		sysCommand(tskCanvas, UI_CANVAS_STARTSECTION, 0)
		drawfunc(tskCanvas)
		sysCommand(tskCanvas, UI_CANVAS_ENDSECTION, 0)
		
	end
	if count == 450 then
		syslog(string.format("CMD UI_CANVAS_SECTIONTRANSLATE"))
		sysCommand(tskCanvas, UI_CANVAS_SECTIONTRANSLATE, 0, 100, 100)
	end
	if count == 500 then
		syslog(string.format("CMD UI_CANVAS_SECTIONCOLOR"))
		sysCommand(tskCanvas, UI_CANVAS_SECTIONCOLOR, 0, 0xff, 0xffffff)
	end
	]]
end


function leave()
end

function drawScaleFunc(canvas)
	sysCommand(canvas, UI_CANVAS_DRAWIMAGESCALE, 0,  0, 0.2, 0, 0xFFFFFF, 255)
	sysCommand(canvas, UI_CANVAS_DRAWIMAGESCALE, 20, 0, 0.2, 1, 0xFFFFFF, 255)
	sysCommand(canvas, UI_CANVAS_DRAWIMAGESCALE, 0, 20, 0.2, 2, 0xFFFFFF, 255)
	-- sysCommand(canvas, UI_CANVAS_FREEZE, true);
end

function drawfunc(canvas)
	sysCommand(canvas, UI_CANVAS_DRAWIMAGE, 0, 0, 0, 0xFFFFFF, 255)
end
--改变canvas显隐
function changerVisiblecanvas(canvas,show)
	syslog(string.format("TASK visible = false"))
		prop = TASK_getProperty(canvas)
		prop.visible = show
	TASK_setProperty(canvas, prop)	
end

function onClick(x,y)

	syslog(string.format("dddd Click (%i,%i)",x,y))
	if ShowState==0 then
			animationName="idle"
	        if currentAnimationIndex==0 then
               animationName="walk"
           
            elseif currentAnimationIndex==1 then
            	animationName="shoot"
            elseif currentAnimationIndex==2 then
            	animationName="run"
            	 elseif currentAnimationIndex==3 then
            	animationName="death"
            	 elseif currentAnimationIndex==4 then
            	animationName="jump"
            	 elseif currentAnimationIndex==5 then
            	animationName="aim"
            	 elseif currentAnimationIndex==6 then
            	animationName="idle"
            end
            currentAnimationIndex=currentAnimationIndex+1
            if currentAnimationIndex>6 then
            	currentAnimationIndex=0
            end

	        sysCommand(CanvasBoy, UI_CANVAS_CHANGERANIMATION, 1,animationName,true)   --注，2个spine都存在一个容器中
	end	
end

function onDblClick( x, y )
	ShowState = 1
	count =0
	syslog(string.format("Double Click (%i,%i)",x,y))
end


function onDrag(mode,x,y,mvX,mvY)
	syslog(string.format("Drag - %i - (%i,%i) - mv : (%i,%i)",mode,x,y,mvX,mvY))
end

function changePos(canvas,deltaTx,deltaTy)
	prop = TASK_getProperty(canvas)
	prop.x =prop.x+ deltaTx
	prop.y = prop.y+deltaTy
	TASK_setProperty(canvas, prop)	
end

function changerScale(canvas,scale)
	prop = TASK_getProperty(canvas)
	prop.scaleX = scale
	prop.scaleY = scale
	TASK_setProperty(canvas, prop)	
end
function hideLable(pLabel)
	prop = TASK_getProperty(pLabel)
	prop.visible = false
	TASK_setProperty(pLabel, prop)	
end
	